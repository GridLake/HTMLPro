package days02;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.util.Properties;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 19. 오전 7:50:46 
 * @subject 환경설정(prop.properties) + Properties컬렉션클래스 
 */
public class Ex01 {

	public static void main(String[] args) {
		// DB 연결 설정 정보를 [???.properties] 파일 저장
		// Properties 컬렉션 클래스를 사용해서 DB설정정보를
		// 읽어와서(로딩) DB 연결...
		// 1) prop.properties
		String fileName = ".\\src\\days02\\prop.properties";
		Properties prop = new Properties();
		try {
			prop.load(new FileReader(fileName));
		} catch (FileNotFoundException e) { 
			e.printStackTrace();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		
		String className = prop.getProperty("className");
		String hostName = prop.getProperty("hostName");
		String sid = prop.getProperty("sid");
		String user = prop.getProperty("user");
		String password = prop.getProperty("password");
		
		//System.out.println( className );
		String url = String.format("jdbc:oracle:thin:@%s:1521:%s"
				, hostName, sid);
		Connection conn = DBConn.getConnection(
				className, url, user, password);
	    System.out.println(conn);	    
	    DBConn.close();
        // oracle.jdbc.driver.T4CConnection@20fa23c1
	} // 

}









// 길환 : 병원 지각 예정 ( 1시 ~2시 올 예정 )
// 치영 : 개인 사정 결석
// 지현 : 정보처리 서류 관련 지각 예정


