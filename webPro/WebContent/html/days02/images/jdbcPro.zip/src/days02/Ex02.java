package days02;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 19. 오전 10:14:41 
 * @subject Statment   , ResultSet 
 */
public class Ex02 {

	public static void main(String[] args) {
		// scott.emp 사원 조회
		/*
		String sql =   "select e.*, d.dname ";
		           sql += "from emp e join dept d ";
		           sql += "                    on  e.deptno = d.deptno ";
		*/
		StringBuffer sb = new StringBuffer();
		sb.append("select e.*, d.dname ");
		sb.append("from emp e join dept d ");
		sb.append("  on  e.deptno = d.deptno ");
		// 1+2
		Connection conn =  DBConn.getConnection();
		// 3
		// 명령처리하는 클래스 : 3 개 종류
		// ㄱ. Statement
		// ㄴ. PreparedStatement : ? ? ? 바인딩변수
		// ㄷ. CallableStatement   : 저장프로시저
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sb.toString());
			int empno ;
			String ename;
			String job ;
			Date hiredate; // (주의) java.sql.Date
			double sal , comm, pay;
			String dname;
			while ( rs.next()   ) {
				 empno = rs.getInt(1);
				 ename = rs.getString("ename");
				 job = rs.getString("job");		
				 hiredate = rs.getDate("hiredate");
				 sal =  rs.getDouble("sal");
				 comm =  rs.getDouble("comm");
				 pay = sal + comm;
				 dname = rs.getString("dname");
				 System.out.printf(
						 "%d %s\t%s\t%tF\t%.2f\t%.2f\t%.2f\t%s\n"
						 , empno
						 , ename
						 , job
						 , hiredate
						 , sal
						 , comm
						 , pay
						 , dname);
				 
			}
			
			rs.close();     // (기억)
			stmt.close(); // (기억)
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// 4
		DBConn.close();
	}

}










