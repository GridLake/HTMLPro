package days02;

public class Ex04 {

	public static void main(String[] args) {
		// emp
		// 1. 모든 사원 정보 출력
		// 2. 사원 추가
		// 3. 사원 검색 ( 사원명, job, 입사년도 , 부서번호 )
		// 4. 사원 번호 입력  수정  (    job, deptno )
		// 5. 사원 삭제.
		
	}

}










