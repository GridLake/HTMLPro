package days02;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 19. 오전 11:35:57 
 * @subject 
 */
public class Ex03 {
	static Connection conn = null;

	public static void main(String[] args) {
		conn = DBConn.getConnection();
		// SimpleDateFormat 클래스
		while(true) {
			메뉴출력();
			메뉴선택();
			메뉴처리();
		}

	} // main

	// enum 열거형 - 변경 ( 실습시간 )
	private static void 메뉴처리() { 
		switch (selectedNumber) {
		case 1: //	"부서정보" 
			getAllDeptInfo();
			break;
		case 2: //  "부서추가"
			addDept();
			break;
		case 3: //  "부서수정"	
			editDept();
			break;
		case 4: //  "부서삭제"
			removeDept();
			break;
		case 5: // "부서검색"		
			searchDept();
			break;
		case 6: // "종료"		
			exit();
			break;
		}
	}

	private static void editDept() {
		System.out.print("> 수정할 부서번호 입력 ? ");
		int deptno = scanner.nextInt();
		String sql = "select * from dept where deptno=" + deptno;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			// 현재 위치에서 다음 행로 이동, false/true
			//int deptno ;
			String dname, loc;
			if( rs.next() ) {
				deptno = rs.getInt(1);
				dname = rs.getString(2);
				loc = rs.getString(3);
				System.out.printf("> %d 상세 정보\n", deptno);
				System.out.printf("deptno : %d\n", deptno); 
				System.out.printf("dname : %s\n", dname);
				System.out.printf("loc : %s\n", loc);
				
				System.out.print("> 수정할 dname, loc 입력 ? ");
 				
				String u_dname = scanner.next()
						, u_loc= scanner.next();
				// update
				sql =String.format( "update dept set dname=%s, loc=%s "
						+ " where deptno=%d", deptno, u_dname, u_loc );
				// stmt
				// stmt.executUpdate(Sql)
				// 
				
				
			}else {
				System.out.println(" 존재하지 않는 부서입니다.");
			}
		} catch (SQLException e) { 
			e.printStackTrace();
		}
		
		/*
		> 수정할 부서번호 입력 ? 10
		> 10 상세 정보
		deptno : 10
		dname  : ACCOUNTING
		loc    : NEW YORK
		> 수정할 dname, loc 입력 ? dname=>ACC , loc=> SEOUL 엔터
		*/
	}

	private static void removeDept() {
		// 검색
		// [] 10
		// [v] 20
		// [] 30
		// [v] 40
		System.out.print("> 삭제할 deptno 입력 ? "); // 20,30
		String  remove_deptnos = scanner.next();
       /*		String sql = "delete from dept ";
		           sql += " where deptno = 30";*/
		String sql = "delete from dept ";
        sql += String.format( " where deptno in (%s)"
        		, remove_deptnos);
		
        System.out.println( sql );
        
        Statement stmt = null;
        try {
			stmt = conn.createStatement();
			int cnt = stmt.executeUpdate(sql);
			if( cnt > 0) {
				System.out.println(cnt +" 개 삭제 완료!!!");
			}
		} catch (SQLException e) { 
			e.printStackTrace();
		}finally {
			try {
				stmt.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
		}
        일시정지();
	}

	private static void searchDept() {
		System.out.println("> 검색 조건 선택");
		System.out.println("   1. 부서명 검색");
		System.out.println("   2. 지역명 검색");
		메뉴선택(); // 1, 2    selectedNumber 저장
		System.out.print("> 검색어 입력 ?");
		String searchWord = scanner.next();
		// 검색어 대문자 변환
		searchWord = searchWord.toUpperCase();
		
		String sql = "select * from dept ";
		switch (selectedNumber) {
		case 1:  // 부서명			
			 sql += " where dname like '%"+searchWord+"%'";
			break;
		case 2: // 지역명
			sql += String.format( 
					" where loc like '%%%s%%'"
					, searchWord);  
		}
		System.out.println( sql );
		// 여러 개의 행 조회 
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<DeptDTO> list = new ArrayList<>();
		DeptDTO dto = null;
		int deptno;		String dname, loc;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				deptno = rs.getInt("deptno");
				dname = rs.getString("dname");
				loc = rs.getString("loc");

				if( selectedNumber == 1) {
					dname = dname.replace(searchWord, "["+ searchWord+"]");
				}else if( selectedNumber == 2) {
					loc = loc.replace(searchWord, "["+ searchWord+"]");
				}
				
				dto = new DeptDTO();
				dto.setDeptno(deptno);
				dto.setDname(dname);
				dto.setLoc(loc);
				
				list.add(dto);
			}
		} catch (SQLException e) { 
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
		} // finally

		// 컬렉션 클래스 출력 ( 복습 )
		System.out.println("> 모든 부서 정보 출력 <");
		Iterator<DeptDTO> ir =  list.iterator();		
		while (ir.hasNext()) {
			dto =  ir.next();
			System.out.println(dto.toString());
		}
		일시정지();

	}

	static char _continue ;
	private static void addDept() {
		// boolean conn.isClosed() 닫힘여부 ? 
		// if(conn.isClosed() ) conn = DBConn.getConnection();
		do {

			System.out.println("[부서정보 입력]");
			System.out.print(" 1. 부서명 입력 ? ");
			String dname = scanner.next();
			System.out.print(" 2. 지역 입력 ? ");
			String loc = scanner.next();
			String sql = 
					String.format(
							"insert into dept ( deptno, dname, loc ) "
									+ "values  (seq_dept.nextval,'%s','%s') "
									, dname, loc );
			// System.out.println( sql ); 확인하는 작업..
			Statement stmt = null;
			try {
				stmt = conn.createStatement();
				// select 			                 stmt.executeQuery(sql)

				// insert, update, delete stmt.executeUpdate(sql)
				// 기본값) 자동 커밋 설정이 되어져 있다. 
				int 영향받은레코드수 = stmt.executeUpdate(sql);
				if( 영향받은레코드수 == 1 ) {
					System.out.println("> 1개 부서 입력 완료!! ");
				}			
			} catch (SQLException e) { 
				e.printStackTrace();
			}finally {
				try {
					stmt.close();
				} catch (SQLException e) { 
					e.printStackTrace();
				}			
			}
			계속여부확인();
		}while( Character.toUpperCase( _continue ) == 'Y' );

		일시정지();
	}

	private static void 계속여부확인() {
		System.out.print("> 부서 추가 계속 ? ");
		try {
			_continue = (char) System.in.read();
			System.in.skip(System.in.available());
		} catch (IOException e) { 
			e.printStackTrace();
		}
	}

	private static void getAllDeptInfo() {
		String sql = "select * from dept";
		
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<DeptDTO> list = new ArrayList<>();
		DeptDTO dto = null;
		int deptno;		String dname, loc;
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				deptno = rs.getInt("deptno");
				dname = rs.getString("dname");
				loc = rs.getString("loc");

				dto = new DeptDTO();
				dto.setDeptno(deptno);
				dto.setDname(dname);
				dto.setLoc(loc);
				list.add(dto);
			}
		} catch (SQLException e) { 
			e.printStackTrace();
		}finally {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
		} // finally

		// 컬렉션 클래스 출력 ( 복습 )
		System.out.println("> 모든 부서 정보 출력 <");
		Iterator<DeptDTO> ir =  list.iterator();		
		while (ir.hasNext()) {
			dto =  ir.next();
			System.out.println(dto.toString());
		}
		일시정지();
	} // 

	public  static void 일시정지() {
		System.out.print("\n 엔터치면 계속합니다.");
		try {
			System.in.read();
			System.in.skip(System.in.available());
		} catch (IOException e) { 
			e.printStackTrace();
		} 
	}

	private static void exit() {
		System.out.println("\t\t 프로그램 종료합니다. ~~");
		DBConn.close();
		System.exit(-1);
	}

	static int selectedNumber;
	static Scanner scanner = new Scanner(System.in)	;

	private static void 메뉴선택() { 
		System.out.print("> 메뉴선택하세요 ? ");
		selectedNumber = scanner.nextInt();
	}

	private static void 메뉴출력() {  
		String [] menus = { "부서정보", "부서추가"
				, "부서수정", "부서삭제","부서검색","종료"};
		System.out.println("> 메뉴 출력 <");
		for (int i = 0; i < menus.length; i++) {
			System.out.printf("%d. %s\n", i+1, menus[i]);
		}		
	}

} // class










