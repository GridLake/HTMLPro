package days03;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IMyBoardDAO {
	// 게시글 작성
	int insert(MyBoardDTO dto) throws SQLException;
	
	// 게시글 목록
	ArrayList<MyBoardDTO> select(int curPage, int pageSize) throws SQLException;
	
	// 게시글 수정
	// 게시글 삭제
	// 게시글 조회수 증가
	// 게시글 보기
	// 총게시글 수 반환
	// 총페이지 수 반환
}










