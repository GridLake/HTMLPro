package days03;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MyBoardDAOImpl implements IMyBoardDAO {
	
	private Connection connection = null;
	private Statement stmt = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	// DI = 생성자, setter 
	public MyBoardDAOImpl(Connection connection) {
		super();
		this.connection = connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}


	@Override
	public int insert(MyBoardDTO dto) throws SQLException {
		
		return 0;
	}

	

	@Override
	public ArrayList<MyBoardDTO> select(int curPage, int pageSize) throws SQLException {
		
		return null;
	}

}










