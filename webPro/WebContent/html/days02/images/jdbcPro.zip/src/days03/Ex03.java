package days03;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 20. 오전 11:51:46 
 * @subject Emp+Dept+Salgrade 컬럼을 가진 새로운 DTO 선언 후 사용. 
 */
public class Ex03 {

	public static void main(String[] args) {
		String sql ="select d.deptno, d.dname, e.empno, e.ename ";
		sql+= "  ,  e.sal + nvl( e.comm, 0) pay ";
		sql+= "  ,  grade ";
		sql+= "  ,  e.mgr   mgr_empno ";
		sql+= "  ,  m.ename mgr_ename ";
		sql+= " from emp e right outer join dept d on e.deptno = d.deptno ";
		sql+= "  left outer join salgrade s on e.sal between s.losal and s.hisal "; 
		sql+= "  left outer join emp m on e.mgr = m.empno  ";

		// 
	}

}










