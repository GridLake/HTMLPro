package days03;

public class Ex02 {

	public static void main(String[] args) {
		String rrn = "123456-7891234";
		if( rrn.matches("\\d{6}-[0-9]{7}") ){
			System.out.println("주민번호 형식 맞다");
		}else {
			System.out.println("주민번호 형식 틀리다");
		}
		
		//rrn.replaceAll(regex, replacement)

	}

}










