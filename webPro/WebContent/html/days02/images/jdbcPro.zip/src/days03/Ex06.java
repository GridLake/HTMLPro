package days03;

public class Ex06 {

	public static void main(String[] args) {
		/*
		 * tbl_myboard 게시판 테이블
		 * 1. MyBoardDTO 클래스            ****
		 * 2. IMyBoardDAO 인터페이스     ****
		 *     MyBoardDAOImpl 클래스 
		 * 3. MyBoardService 클래스
		 * 4. MyBoardController 클래스
		 * 5. Ex06.java + main(){
		 *     //
		 *     MyBoardController. 메서드 구현
		 * }    
		 * */
	}

}










