package days03;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 20. 오전 7:43:23 
 * @subject 길환(10),순호(거의),예나(5)
 */
public class Ex01 {

	public static void main(String[] args) {
		/* [복습문제]
		 * 게시판 테이블( tbl_myboard ) 에서
		 * ㄱ. 검색조건 선택
		 * 	1. 제목
		 * 	2. 글쓴이
		 * 	3. 제목 + 내용
		 * ㄴ. 검색어 입력 받아서 대소문자 구분 없이 검색 
		 * ㄷ. MyBoardDTO 클래스 선언 후 검색 결과를  ArrayList 에 
		 *      담아서   iterator를 사용해서 검색 결과 출력.
		 * ㄹ. 글번호, 제목, 글쓴이, 작성일 컬럼만 출력.
		 *      select seq, subject, name, regdate from tbl_myboard
		 * */
		
		System.out.println("[검색조건]");
		System.out.println("\t 1. 제목");
		System.out.println("\t 2. 글쓴이");
		System.out.println("\t 3. 제목+내용");
		
		int selectNumber = 0;
		Scanner sc = new Scanner(System.in);
		System.out.printf("> 검색조건 , 검색어 선택 ? ");
		selectNumber = sc.nextInt();
		String searchWrod = sc.next();
		
		String sql = "select seq, subject, name, regdate "
				           + "from tbl_myboard ";
		switch (selectNumber) {
		case 1: // 제목	 
			sql +=" where subject like '%"+ searchWrod +"%'";
			break;
		case 2: // 글쓴이
			//sql += String.format(" where name like '%%%s%%'"
			//		, searchWrod);
			sql += String.format(" where name like '%s'"
			 		, "%"+searchWrod+"%");
			break;
		case 3: // 제목 + 내용  ( subject , 'ke' , 'i' )
			sql += String.format(
					" where  regexp_like(subject,  '%1$s', 'i' ) "
					+ " or regexp_like(content,  '%1$s', 'i' )"
			 		, searchWrod);
			// where upper(subject) like
			//     searchWord.toUpperCase()
			break;
		}
		
		// System.out.println( sql );
		Connection conn = null;
		Statement  stmt = null;
		ResultSet   rs      = null;
		ArrayList<MyBoardDTO> list = null;
		MyBoardDTO dto = null;
		try {
			conn = DBConn.getConnection();
			stmt = conn.createStatement();
			rs      = stmt.executeQuery(sql);
			days02.Ex03.일시정지();
			if( rs.next() ) {
				list = new ArrayList<>();
				do {
					dto = new MyBoardDTO();					
						dto.setSeq( rs.getInt("seq") ); // rs.getInt(1) // rs[1]
						dto.setSubject( rs.getString("subject") );		  // rs[2]			 
						dto.setName( rs.getString("name") );
						dto.setRegdate( rs.getDate("regdate") );          // rs[4]
					list.add(dto);
				}while(rs.next());
			}else {
				// 검색 결과 없음.
			}
			
		} catch (SQLException e) { 
			e.printStackTrace();
		}
		
		// list == null ( 기억 )
		if( list == null ) {
			System.out.println(" 검색 결과 없습니다. ");
			return;
		}
		
		Iterator<MyBoardDTO> ir = list.iterator();
		while (ir.hasNext()) {
			dto = ir.next();
			
			Pattern pattern = Pattern.compile(searchWrod
					, Pattern.CASE_INSENSITIVE);			
			Matcher matcher = pattern.matcher(dto.getSubject());			
			dto.setSubject( matcher.replaceAll("["+searchWrod+"]") );
			
			System.out.println(dto.toString());
		}
		
		
		/*
		1. DTO 
		   ㄱ. 데이터 전송 객체(Data transfer object)
		2. DAO
		   ㄱ. 데이터 접근 객체(Data Access Object)
		   
		 웹브라우저      ->  웹서버  ->  비즈니스 로직 (미들웨어)  -> Oracle
		 클라이언도구     
		                        DTO                               DTO
		                                                                        DAO(CRUD)
		                                                                        
         3. VO
             ㄱ. Value Object - Data 값 객체 
          
         4. VO  DTO
             VO =  DTO , 자바빈즈 , POJO
         
         5. 자바 빈즈( Java Bean )
            ㄱ. Data를 관리하기 위한 목적으로 생성된 java 클래스.
            ㄴ. Data 효율적인 관리 목적
                구성 = 데이터 표현 부분 + 데이터 처리 부분
                              필드                        메서드             
           ㄷ. 자바 빈 규칙
              1) 디폴트 생성자
              2) private 필드
              3)  getter / setter 
              
         6.      POJO  	
            ㄱ. Plain Old Java Object
                ( 평범한 옛날 자바 객체 )
           ㄴ.  Java EE + 프레임워크 : POJO     	                                                                        
        */
	} // main

} // class










