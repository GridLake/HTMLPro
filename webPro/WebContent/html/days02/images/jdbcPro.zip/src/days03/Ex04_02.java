package days03;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.util.DBConn;

import days02.DeptDTO;

public class Ex04_02 {

	public static void main(String[] args) {
		String sql = 
				"select d.*"
				+ "          , (select count(*) from emp where deptno = d.deptno ) numberOfEmp "
				+ "from dept d";
		Connection con = null;
		Statement stmtDept = null, stmtEmp = null;
		ResultSet  rsDept = null, rsEmp = null;
		//
		/*
		Hashtable<DeptDTO, ArrayList<EmpDTO>> ht 
		 = new Hashtable<>();
		*/
		
		// 순서 유지 O 
		LinkedHashMap<DeptDTO, ArrayList<EmpDTO>> ht
	    = new LinkedHashMap<>();
		
		try {
			con = DBConn.getConnection();
			stmtDept = con.createStatement();
			rsDept = stmtDept.executeQuery(sql);
			while ( rsDept.next() ) {
				int deptno = rsDept.getInt("deptno");
				String dname = rsDept.getString("dname");
				String loc = rsDept.getString("loc");
				int numberOfEmp = rsDept.getInt("numberOfEmp");
				
				DeptDTO dto = new DeptDTO();
					dto.setDeptno(deptno);
					dto.setDname(dname);
					dto.setLoc(loc);
					dto.setNumberOfEmp(numberOfEmp);
				
				/* 
				System.out.printf("%d(%s) - %d명\n"
						, deptno, dname, numberOfEmp);
			    */
				sql = String.format( 
						"select rownum, emp.* from emp "
						+ "where deptno = %d", deptno);
				stmtEmp = con.createStatement();
				rsEmp = stmtEmp.executeQuery(sql);	
				
				ArrayList<EmpDTO> list  = null;
				
				if (rsEmp.next()) {
					list = new ArrayList<>();
					do {
						int rownum = rsEmp.getInt("rownum");
						int empno = rsEmp.getInt("empno");
						String ename = rsEmp.getString("ename");
						String job = rsEmp.getString("job");
						Date   hiredate = rsEmp.getDate("hiredate");
						
						EmpDTO empDto = new EmpDTO();
						empDto.setEmpno(empno);
						empDto.setEname(ename);
						empDto.setJob(job);
						empDto.setHiredate(hiredate);
						
						list.add(empDto);
						/*
						System.out.printf("\t%d\t%d\t%s\t%s\t%tF\n"
								,rownum, empno, ename, job, hiredate);
						*/
					} while (rsEmp.next());
				}else {
					//System.out.println("\t 사원 존재하지 않습니다.");
					list = new ArrayList<>();
				}
				
				ht.put(dto, list);
				 
			} // while  dept
			
		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			try {
				rsDept.close();
				stmtDept.close();
				
				rsEmp.close();
				stmtEmp.close();
				DBConn.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}			
		} // finally 
		
		// [ht 출력....]
		// System.out.println( ht.size() );
	 
		Set<Entry<DeptDTO, ArrayList<EmpDTO>>> set = ht.entrySet();
		Iterator<Entry<DeptDTO, ArrayList<EmpDTO>>>  ir = set.iterator();
		
		while (ir.hasNext()) {
			Entry<DeptDTO,ArrayList<EmpDTO>> entry = ir.next();
			DeptDTO dto =  entry.getKey();
			System.out.printf("%d(%s) - %d명\n"
					, dto.getDeptno(), dto.getDname()
					, dto.getNumberOfEmp());
			// 부서 소속 사원 정보 출력 코딩 추가
			ArrayList<EmpDTO>  elist = entry.getValue();
			Iterator<EmpDTO>   eir = elist.iterator();
			while (eir.hasNext()) {
				EmpDTO edto = eir.next();
				System.out.printf("\t%d\t%s\t%s\t%tF\n"
					  , edto.getEmpno(), edto.getEname()
					  , edto.getJob(), edto.getHiredate());
				
			}
		}
		 
	} //

} // 


/*
 *  Hashtable<DeptDTO, ArrayList<EmpDTO>> ht = new Hashtable();
 *  select * from dept;
 *  while(){
 *     
 *     
 *     select * from emp where deptno=10,40
 *     while(){
 *     
 *     }
 *     
 *  }
 *  
 *  ht
 * 
 * */



