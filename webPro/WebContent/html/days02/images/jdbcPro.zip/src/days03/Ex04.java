package days03;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;

import com.util.DBConn;

import days02.DeptDTO;

public class Ex04 {

	public static void main(String[] args) {
		// 부서번호(deptno)
		// 부서 사원 정보 
		// String sql = "select * from dept";
		String sql = 
				"select d.*"
				+ "          , (select count(*) from emp where deptno = d.deptno ) numberOfEmp "
				+ "from dept d";
		Connection con = null;
		Statement stmtDept = null, stmtEmp = null;
		ResultSet  rsDept = null, rsEmp = null;
		//
		try {
			con = DBConn.getConnection();
			stmtDept = con.createStatement();
			rsDept = stmtDept.executeQuery(sql);
			while ( rsDept.next() ) {
				int deptno = rsDept.getInt("deptno");
				String dname = rsDept.getString("dname");
				String loc = rsDept.getString("loc");
				int numberOfEmp = rsDept.getInt("numberOfEmp");
				System.out.printf("%d(%s) - %d명\n"
						, deptno, dname, numberOfEmp);
				
				sql = String.format( 
						"select rownum, emp.* from emp where deptno = %d", deptno);
				stmtEmp = con.createStatement();
				rsEmp = stmtEmp.executeQuery(sql);		
				if (rsEmp.next()) {
					do {
						int rownum = rsEmp.getInt("rownum");
						int empno = rsEmp.getInt("empno");
						String ename = rsEmp.getString("ename");
						String job = rsEmp.getString("job");
						Date   hiredate = rsEmp.getDate("hiredate");
						System.out.printf("\t%d\t%d\t%s\t%s\t%tF\n"
								,rownum, empno, ename, job, hiredate);
					} while (rsEmp.next());
				}else {
					System.out.println("\t 사원 존재하지 않습니다.");
				}
				 
			}
			
		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			try {
				rsDept.close();
				stmtDept.close();
				
				rsEmp.close();
				stmtEmp.close();
				//con.close();
				DBConn.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}			
		} // finally 

	} //

} // 

/*
 * 10(dname) - 3명
 *   1) 7369 SMITH HIRE....
 *   2)
 *   3)
 *   
 * 20(dname) - 3명
 *   1)
 *   2)
 *   3)
 *   
 * 30(dname) - 6명
 *   1)
 *   6)
 * 
 * 40(dname) - 0명
 *        
 * 
		ArrayList<EmpDTO> elist = null;
		DeptDTO d_dto = new DeptDTO();		d_dto.setDeptno(10);
		EmpDTO  e_dto = new EmpDTO();		e_dto.setEmpno(1);
		elist = new ArrayList<>();
		elist.add(e_dto);
		Hashtable<DeptDTO, ArrayList<EmpDTO>> ht = new Hashtable<>();
		ht.put(d_dto, elist);
		
		d_dto = new DeptDTO();		d_dto.setDeptno(20);
		e_dto = new EmpDTO();		e_dto.setEmpno(2);
		elist = new ArrayList<>();
		elist.add(e_dto);
		ht.put(d_dto, elist);
		
		d_dto = new DeptDTO();		d_dto.setDeptno(30);
		elist = new ArrayList<>();		elist.add(e_dto);
		ht.put(d_dto, elist);
		
		System.out.println(ht.size());
		
		ht.entrySet();
 * */











