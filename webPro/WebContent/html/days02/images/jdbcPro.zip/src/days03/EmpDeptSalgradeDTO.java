package days03;

import java.sql.Date;

public class EmpDeptSalgradeDTO {
	
	private int deptno;
	private String dname;
	private int empno;
	private String ename;   
	private double pay;      // 
	private int grade;
	private int mgr_empno;
	private String mgr_ename;
	
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getPay() {
		return pay;
	}
	public void setPay(double pay) {
		this.pay = pay;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public int getMgr_empno() {
		return mgr_empno;
	}
	public void setMgr_empno(int mgr_empno) {
		this.mgr_empno = mgr_empno;
	}
	public String getMgr_ename() {
		return mgr_ename;
	}
	public void setMgr_ename(String mgr_ename) {
		this.mgr_ename = mgr_ename;
	}
	
	public EmpDeptSalgradeDTO() {
		super(); 
	}
	
	@Override
	public String toString() { 
		return super.toString();
	} 

}










