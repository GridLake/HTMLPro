package days03;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import days02.DeptDTO;

public class Ex05 {

	public static void main(String[] args) {
		/*
		java.lang.NullPointerException
		DeptDTO dto = null;
		dto.setDeptno(10);
		*/
		
		/*
		Hashtable<Integer, ArrayList<String>> ht = new Hashtable<>();
		
		//             key=부서번호  value= 사원들
		ArrayList<String> list_10 = new ArrayList<>();
		list_10.add("홍길동");
		list_10.add("김길환");
		list_10.add("함치영");		
		ht.put(10, list_10);
		
		ArrayList<String> list_20 = new ArrayList<>();
		list_20.add("A");
		list_20.add("B");
		list_20.add("C");
		ht.put(20, list_20);
		
		Set<Entry<Integer, ArrayList<String>>>  set = ht.entrySet();
		Iterator<Entry<Integer, ArrayList<String>>> ir = set.iterator();
		while (ir.hasNext()) {
			Entry<Integer,ArrayList<String>> entry = ir.next();
			System.out.println(entry.getKey());
			ArrayList<String> list = entry.getValue();
			// System.out.println("\t" + list);
			Iterator<String>  irs= list.iterator();
			while (irs.hasNext()) {
				String name =   irs.next();
				System.out.println("\t" + name);
			}
		}
		*/
		
		
		// 
		// System.out.println( ht.size() );
		// 출력
		// 10
		//   1 A
		//   2 B
		//   3 C
		// 20
		//   1 x
		//   2 y
		
		// 모든 key
		// 모든 value
		// 모든 entry= key + value
		
		
		
		
		// list 순서 유지, 중복 허용
		// 마치 배열 동일 + 단점 -> 컬렉션 클래스
		/*
		ArrayList<String> list = new ArrayList<>();
		list.add("홍길동");
		list.add("김길환");
		list.add("함치영");
		// [홍길동, 김길환, 함치영]
		System.out.println(list);
		 
		for (int i = 0; i < list.size() ; i++) {
			System.out.println(list.get(i));
		}
	     
		Iterator<String> ir = list.iterator();
		while (ir.hasNext()) {
			String name =  ir.next();
			System.out.println(name);
		}
        */
	}

}










