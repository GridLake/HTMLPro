package days01;

import java.sql.Connection;

import com.util.DBConn;

public class Ex02 {

	public static void main(String[] args) {
		Connection conn = DBConn.getConnection();
		System.out.println( conn );
		// oracle.jdbc.driver.T4CConnection@4d76f3f8
		//conn.close();  주의 설명
		DBConn.close();
	}

}
