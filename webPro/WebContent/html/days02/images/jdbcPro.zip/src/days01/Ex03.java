package days01;

import java.sql.Connection;

import com.util.DBConn;

public class Ex03 {

	public static void main(String[] args) {
		String className = "oracle.jdbc.driver.OracleDriver";
		String url= 
				String.format("jdbc:oracle:thin:@%s:1521:%s"
						, "211.63.89.163"
						, "xe");
		String user = "scott";
		String password = "tiger";
		Connection conn = DBConn.getConnection(className, url, user, password);
		System.out.println( conn ); 
		DBConn.close(); 
	}

}
