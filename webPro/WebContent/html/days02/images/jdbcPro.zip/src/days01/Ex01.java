package days01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author SIST163
 * 오라클 발표 후  JDBC 수업 01 예제
 * Alt + Shift + J
 */
public class Ex01 {

	public static void main(String[] args) {		
		String className = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe"; // Type 4
		String user = "scott";
		String password ="tiger";
		Connection  conn = null;
		try {
			// 1. Class.forName()  드라이브 로딩
			Class.forName(className);	
			// 2. DriverManager.getConnection() -> Connection 객체
			conn = DriverManager.getConnection(url, user, password);
			System.out.println( conn );
		} catch (ClassNotFoundException e) { 
			e.printStackTrace();
		} catch (SQLException e) { 
			e.printStackTrace();
		}  
		// 3. DML  명령 수행
		// 4. Connection객체 close().
		try {
			conn.close();
		} catch (SQLException e) { 
			e.printStackTrace();
		}
		 
 
	}

}

// com.util 패키지
// DBConn 클래스 
// 싱글톤 
 
