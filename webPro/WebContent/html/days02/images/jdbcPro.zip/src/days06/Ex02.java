package days06;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.util.ConnFactory;

public class Ex02 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// 한 공장. 
		ConnFactory factory = ConnFactory.getDefaultFactory();
		// Connection 
		Connection conn =  factory.createConnection();
		
		Statement stmt = conn.createStatement();		
		ResultSet rs = stmt.executeQuery("select * from dept");		
		while(rs.next()) {
			System.out.print(rs.getString("deptno") + " ");
			System.out.print(rs.getString("dname") + " ");
			System.out.println(rs.getString("loc"));
		}		
		rs.close();
		stmt.close();
		conn.close();

	}

} //














