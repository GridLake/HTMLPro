package days06;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 25. 오전 7:37:59 
 * @subject 
 */
public class Ex01 {

	public static void main(String[] args) throws IOException {		
		Properties p = new Properties();
			p.put("Driver", "oracle.jdbc.driver.OracleDriver");
			p.put("URL", "jdbc:oracle:thin:@localhost:1521:xe");
			p.setProperty("MaxConn", "10");
			p.setProperty("User", "scott");
			p.setProperty("Password", "tiger");		
		FileOutputStream out = 
				new FileOutputStream(
						".\\src\\days06\\jdbc.properties");
		p.store(out, "JDBC Config Setting");
		out.close();
		
		System.out.println("END");
		
	} // main 

} // class









// 희수 : 결석
// 현구 : 결석
// 주영 : 결석

