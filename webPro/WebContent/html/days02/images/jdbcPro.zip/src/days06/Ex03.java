package days06;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.util.Vector;

import com.util.ConnPool;

public class Ex03 {

	public static void main(String[] args) 
			throws SQLException, InterruptedException{
		ConnPool pool = ConnPool.getConnPool();
		Connection conn = pool.getConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from dept");		
		while(rs.next()) {
			System.out.print(rs.getString("deptno") + " ");
			System.out.print(rs.getString("dname") + " ");
			System.out.println(rs.getString("loc"));
		}		
		rs.close();
		stmt.close();
		pool.releaseConnection(conn);
		//ConnPool.destroyConnPool();

	}
}












