package days05;

import java.awt.Window.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 22. 오후 4:24:32 
 * @subject ResultSet 결과물에 대한 정보 추출 및 사용 예제 
 */
public class Ex08 {

	public static void main(String[] args) {
		 String sql = "select  rownum seq, table_name from tabs";
		 Connection con = null;
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 
		 try {
			con = DBConn.getConnection();			
			pstmt = con.prepareStatement(sql);
			rs =  pstmt.executeQuery();
			while (rs.next()) {
				System.out.printf("%d. %s\n"
						, rs.getInt(1), rs.getString(2));
			}
			pstmt.close();
			rs.close();
			// 
			System.out.print("> 테이블 선택하세요 ? ");
			Scanner scanner = new Scanner(System.in);
			String tableName = scanner.next();
			// 
			sql = "select * from  " + tableName;  // dept, salgrade
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			// 출력 : ResultSet 으로부터  컬럼명, 자료형, 크기 파악
			ResultSetMetaData rsmd = rs.getMetaData();
			//
			System.out.println( "> 컬럼 갯수 : " + rsmd.getColumnCount() );
			// 컬럼명 출력
			System.out.println("--------------------------------------");
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				System.out.printf("%s\t", rsmd.getColumnName(i));
			}
			System.out.println("\n--------------------------------------");
			// 레코드(행) 출력....
			while(rs.next()) {
				/*
				rs.getInt(columnIndex);
				rs.getString(columnIndex)
				rs.getDate(columnIndex)
				rs.getDouble(columnIndex)
				*/
				for (int i = 1; i <= rsmd.getColumnCount() ; i++) {
					int columType = rsmd.getColumnType(i);
					int scale = rsmd.getScale(i); // double  number( p,s )
					if( columType == Types.NUMERIC && scale != 0 ) {  // double
						System.out.printf("%.2f\t", rs.getDouble(i));
					}else if(columType == Types.NUMERIC && scale == 0 ) {  // int
						System.out.printf("%d\t", rs.getInt(i));
					}else if(columType == Types.VARCHAR || 
							columType == Types.CLOB ) {
						System.out.printf("%s\t", rs.getString(i));
					}else if(columType == Types.DATE || 
							columType == Types.TIMESTAMP) {
						System.out.printf("%tF\t", rs.getDate(i));
					}	
					
				}
				System.out.println();
			}
			System.out.println("--------------------------------------");
			// 
			
			
		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				rs.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
			DBConn.close();
		}

	} // main

} // class










