package days05;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 22. 오후 3:24:32 
 * @subject 
 */
public class Ex06 {

	public static void main(String[] args) {
		int empno;
		String ename, job;
		Date hiredate;
		
		System.out.print("> empno input ? ");
		Scanner scanner = new Scanner(System.in);
		empno = scanner.nextInt(); 
		// 
		Connection connection = null;
		CallableStatement cstmt = null;
		
		String sql = "{ CALL  UP_SELECTEMP(?,?,?,?) }";
		
		try {
			connection =  DBConn.getConnection();
			cstmt = connection.prepareCall(sql);
cstmt.setInt(1, empno);  
			cstmt.registerOutParameter(2
					,  oracle.jdbc.OracleTypes.VARCHAR );
			cstmt.registerOutParameter(3
					,  oracle.jdbc.OracleTypes.VARCHAR );
			cstmt.registerOutParameter(4
					,  oracle.jdbc.OracleTypes.DATE );
			
cstmt.executeQuery();
			 
			ename = (String) cstmt.getObject(2);
			job = (String) cstmt.getObject(3);
			hiredate = (Date) cstmt.getObject(4);
			 
		    System.out.printf("%s - %s - %tF\n", 
		    		ename, job, hiredate);
		    
		} catch (SQLException e) { 
			// e.printStackTrace();
			if( e.getErrorCode() == 20002 )
				System.out.println("empno 가 존재하지 않습니다.");
		} finally {
			try {
				cstmt.close(); 
				DBConn.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
		}
		 
	}  // main 닫기

}

/*
create or replace procedure up_selectEmp
(
   pempno  in number
   , pename out varchar2
   , pjob  out varchar2
   , phiredate out date
)
is
  vsql varchar2(1000);
begin
   vsql :=         '  select ename, job, hiredate '; 
   vsql := vsql || '  from emp ' ;
   vsql := vsql || '  where empno = :pempno ';
   
   execute immediate vsql  
       into   pename, pjob, phiredate
       using pempno;
exception
   when no_data_found then
      raise_application_error(-20002, 'Data Not Found...');
   when others then
     raise_application_error(-20004, 'Othres Error...');
end;
-- Procedure UP_SELECTEMP이(가) 컴파일되었습니다.

*/








