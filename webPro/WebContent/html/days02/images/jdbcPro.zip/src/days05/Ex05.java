package days05;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 22. 오후 3:06:39 
 * @subject 
 */
public class Ex05 {

	public static void main(String[] args) {		
		int empno;
		String ename ;
		System.out.print("> id(empno), pwd(ename) input ? ");
		Scanner scanner = new Scanner(System.in);
		empno = scanner.nextInt();
		ename = scanner.next();
		// 
		Connection connection = null;
		CallableStatement cstmt = null;
		
		String sql = "{ CALL  up_empLogon(?,?,?) }";
		
		int logonCheck  = 0;
		try {
			connection =  DBConn.getConnection();
			cstmt = connection.prepareCall(sql);
			cstmt.setInt(1, empno);
			cstmt.setString(2, ename); 
			cstmt.registerOutParameter(3
					,  oracle.jdbc.OracleTypes.INTEGER );
			cstmt.executeQuery();
			 
			logonCheck = (int) cstmt.getObject(3);
			 
		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			try {
				cstmt.close(); 
				DBConn.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
		}
		//
		if( logonCheck ==1 ) 	           System.out.println("로그인 성공");
	    else if( logonCheck == 0)   	System.out.println("아이디(empno) 존재하지 않습니다.");
	   else         System.out.println("비밀번호(ename)이 잘못되었습니다.");
 
	}

}










