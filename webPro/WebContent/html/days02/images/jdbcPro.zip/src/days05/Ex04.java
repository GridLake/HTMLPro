package days05;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.util.DBConn;

import days03.EmpDTO;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 22. 오후 2:40:33 
 * @subject ID중복체크 버튼 구현.
 *                 출력용 매개변수 사용 예
 *                 CallableStatement 사용 예
 */
public class Ex04 {

	public static void main(String[] args) {
		int empno;
		Scanner scanner = new Scanner(System.in);
		System.out.printf("> 중복체크할 id(empno) input ? ");
		empno = scanner.nextInt();
		//up_empnoCheck
		Connection connection = null;
		CallableStatement cstmt = null;
		
		String sql = "{ CALL  up_empnoCheck(?,?) }";
		
		
		int idCheck  = 0;
		try {
			connection =  DBConn.getConnection();
			cstmt = connection.prepareCall(sql);
			cstmt.setInt(1, empno); 
			cstmt.registerOutParameter(2
					,  oracle.jdbc.OracleTypes.INTEGER );
			cstmt.executeQuery();
			 
			idCheck = (int) cstmt.getObject(2);
			 
		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			try {
				cstmt.close(); 
				DBConn.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
		}
		// 
		if( idCheck == 1) {
			System.out.println("이미 존재하는 ID입니다.");
		}else {
			System.out.println("사용가능한 ID입니다. ");
		}
		
	}

}










