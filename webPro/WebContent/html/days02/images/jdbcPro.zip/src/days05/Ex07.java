package days05;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 22. 오후 3:45:33 
 * @subject 트랜잭션 처리  
 */
public class Ex07 {

	public static void main(String[] args) {
		String sql = "{ call UP_INSERTDEPT(?,?,?) }";
		 
		 Connection connection = DBConn.getConnection();
		 CallableStatement cstmt = null;		
		 try{
connection.setAutoCommit(false); // (기본) auto commit 
			cstmt = connection.prepareCall(sql);
			cstmt.setInt(1, 90);
			cstmt.setString( 2, "영업부" );
			cstmt.setString( 3, "서울" ); 			
			int resultCnt = cstmt.executeUpdate();
			if( resultCnt == 1) System.out.println("> 1. 부서 저장 완료!!!");
			
			cstmt = connection.prepareCall(sql);
			cstmt.setInt(1, 90); // 오류 발생....
			cstmt.setString( 2, "총무부" );
			cstmt.setString( 3, "부산" ); 			
			resultCnt = cstmt.executeUpdate();
			if( resultCnt == 1) System.out.println("> 2. 부서 저장 완료!!!");
connection.commit(); //  커밋..			
		} catch (SQLException e) { 
             e.printStackTrace();
try {
	connection.rollback();
} catch (SQLException e1) {  
	e1.printStackTrace();
}  		
		} finally {
			try {
				cstmt.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
			DBConn.close();
		}

	}

}










