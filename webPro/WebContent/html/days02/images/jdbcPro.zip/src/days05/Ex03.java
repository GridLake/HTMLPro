package days05;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.util.DBConn;

import days03.EmpDTO;

public class Ex03 {

	public static void main(String[] args) {
		// String sql = "{ CALL 프로시저명(?,?,?) }";
		// String sql = "{ CALL 프로시저명 }";
		// String sql = "{ CALL 프로시저명(pdanme=>?,ploc=>?) }";
		// > dept 테이블에 up_insertdept 부서추가....
		
		// UP_SELECTEMP
		Scanner scanner = new Scanner(System.in);
		System.out.printf("> deptno input ? ");
		int deptno = scanner.nextInt();
		//
		Connection connection = null;
		CallableStatement cstmt = null;
		ArrayList<EmpDTO> list = null;
		ResultSet rs = null;
		// 
		String sql = "{ CALL  UP_SELECTEMP(?,?) }";
		
		try {
			connection =  DBConn.getConnection();
			cstmt = connection.prepareCall(sql);
			cstmt.setInt(1, deptno); // in 매개변수 설정.
			// (기억) out 매개변수 설정 ? 
			cstmt.registerOutParameter(2
					,  oracle.jdbc.OracleTypes.CURSOR );
			cstmt.executeQuery();
			 
			rs = (ResultSet) cstmt.getObject(2);
			
			if(rs.next()) {
				list = new ArrayList<>();
				EmpDTO dto = null;
				do {
					// deptno, empno, ename, job, hiredate
					dto = new EmpDTO();
						dto.setDeptno( rs.getInt("deptno") );
						dto.setEmpno( rs.getInt("empno") );
						dto.setEname( rs.getString("ename") );
						dto.setJob( rs.getString("job") );
						dto.setHiredate( rs.getDate("hiredate") );
					list.add(dto);
				} while (rs.next());
			}else {
				System.out.println(" 결과 없음.");
			}
		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			try {
				cstmt.close();
				rs.close();
				DBConn.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}
		}
		

		printEmpInfo(list);
	}  // main

	private static void printEmpInfo(ArrayList<EmpDTO> list) {
		if( list == null ) return;
		else  {
			Iterator<EmpDTO> ir =  list.iterator();
			while (ir.hasNext()) {
				EmpDTO dto =  ir.next();
				//System.out.println( dto.toString() );
				System.out.printf("%d-%s\t%s\n", 
						dto.getDeptno(), dto.getEname(), dto.getJob());
			}
		}
	}

}











