package days05;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 22. 오전 8:37:01 
 * @subject 
 */
public class Ex01 {

	public static void main(String[] args) {
		int currentPage = 1;             // 현재 페이지 번호
		int numberPerPage = 10;
		int numberOfPageBlocks = 10;
		int numberOfPostings = 573;
		int numberOfPages = 58;
		
		int pageBlockStart = 1;
		int pageBlockEnd = 10;
		
		for (int i = 1; i <=numberOfPages; i++) {
			pageBlockStart = (i-1)/numberOfPageBlocks
					                             *numberOfPageBlocks + 1;
			pageBlockEnd = pageBlockStart + numberOfPageBlocks -1;
			if( pageBlockEnd > numberOfPages)	pageBlockEnd = numberOfPages;
			//System.out.printf("%d 페이지 : %d ... %d\n"
			//		, i, pageBlockStart, pageBlockEnd);
			
			System.out.printf("%d 페이지 : " , i);
			if( pageBlockStart != 1 ) System.out.print("  ◀ ");
			for (int j = pageBlockStart; j <= pageBlockEnd; j++) {
				System.out.printf( j == i ? "[%2d] " : "%2d ", j );
			}
			if( pageBlockEnd !=  numberOfPages) System.out.print("▶");
			System.out.println();
		}
		/*           
		 * 1페이지     [ 1]  2  3  4  5  6  7  8  9 10   ▶
		 * 2페이지        1  [2]  3  4  5  6  7  8  9 10   ▶
		 * :
		 * 10페이지     1  2  3  4  5  6  7  8  9 [10]   ▶
		 * 11페이지  ◀  [11] 12 13 14 15 16 17 18 19 20   ▶
		 * 20페이지  ◀  11 12 13 14 15 16 17 18 19 [20]   ▶ 
		 * 56페이지  ◀  51~ [56] 57 58 
		 * */
		

	}

}



/*
지현 : 아파서 결석
동현 : 개인사정으로 결석

순호 : 10분 지각예정 

currentPage                   // 현재 페이지 번호
numberPerPage             // 페이지당 게시글 수
numberOfPageBlocks    // 페이지블럭 수
numberOfPages             // 총 페이지 수
	
*/















