package days05;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.util.DBConn;

/**
 * @author   k≡n¡k
 * @date      2019. 3. 22. 오전 11:49:28 
 * @subject  저장 프로시저  +		 CallableStatement 
 */
public class Ex02 {

	public static void main(String[] args) {
		
		 String sql = "{ call UP_INSERTDEPT(?,?) }";
		 
		 String pdname, ploc;
		 System.out.print("> dname, loc input ? ");
		 Scanner scanner = new Scanner(System.in);
		 
		 pdname = scanner.next();
		 ploc = scanner.next();
		 
		 Connection connection = DBConn.getConnection();
		 //CallableStatement cstmt = null;
		 try( CallableStatement cstmt =
				 connection.prepareCall(sql) ) {
			//cstmt = connection.prepareCall(sql);
			cstmt.setString( 1, pdname );
			cstmt.setString( 2, ploc ); 
			
			int resultCnt = cstmt.executeUpdate();
			if( resultCnt == 1) 
				System.out.println("> 부서 저장 완료!!!");
		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			//cstmt.close();
			DBConn.close();
		}
		 
	} // 

}










