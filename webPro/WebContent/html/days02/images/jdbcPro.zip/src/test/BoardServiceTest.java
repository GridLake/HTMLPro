package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.util.DBConn;

import days04.MyBoardDAOImpl;
import days04.MyBoardService;

class BoardServiceTest {

	@Test
	void test() {
		//fail("Not yet implemented");
		MyBoardDAOImpl boardDao = 
				new MyBoardDAOImpl(DBConn.getConnection());
		MyBoardService service = new MyBoardService(boardDao);
		System.out.println(
				service.pagingBlockService(25, 10, 10) 
				);
	}

}










