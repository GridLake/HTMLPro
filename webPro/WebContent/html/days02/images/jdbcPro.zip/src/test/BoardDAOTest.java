package test;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import com.util.DBConn;

import days04.MyBoardDAOImpl;
import days04.MyBoardDTO;

class BoardDAOTest {

	@Test
	void test() throws SQLException {
		// fail("Not yet implemented");
		MyBoardDAOImpl boardDao = 
				new MyBoardDAOImpl(DBConn.getConnection());
		int numberOfPages = boardDao.getNumberOfPages(10);
		System.out.println( "총페이지수 : " + numberOfPages );
	}

}










