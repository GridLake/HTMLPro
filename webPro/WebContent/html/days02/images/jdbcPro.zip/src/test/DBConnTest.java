package test;

import java.sql.Connection;

import org.junit.jupiter.api.Test;

import com.util.DBConn;

class DBConnTest {

	@Test
	void test() {
		Connection conn = DBConn.getConnection();
		System.out.println(conn);
		DBConn.close();
		
		
	}

}










