package days04;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;

import com.util.DBConn;

import days02.DeptDTO;

public class Ex02 {

	public static void main(String[] args) {

		String sql = null;
		Connection con = null;
		PreparedStatement  pstmtEmp = null;
		ResultSet   rsEmp = null;
		//
		try {
			con = DBConn.getConnection();	
			sql =  "select rownum, emp.* from emp "
					+ "where deptno = ?";
			pstmtEmp = con.prepareStatement(sql);
			// ? 바인딩변수 값을 설정 코딩..
			pstmtEmp.setInt(1, 30);
			
			rsEmp = pstmtEmp.executeQuery();
					
			if (rsEmp.next()) {
				do {
					int rownum = rsEmp.getInt("rownum");
					int empno = rsEmp.getInt("empno");
					String ename = rsEmp.getString("ename");
					String job = rsEmp.getString("job");
					Date   hiredate = rsEmp.getDate("hiredate");
					System.out.printf("\t%d\t%d\t%s\t%s\t%tF\n"
							,rownum, empno, ename, job, hiredate);
				} while (rsEmp.next());
			}else {
				System.out.println("\t 사원 존재하지 않습니다.");
			}



		} catch (SQLException e) { 
			e.printStackTrace();
		} finally {
			try {
				rsEmp.close();
				pstmtEmp.close();
				//con.close();
				DBConn.close();
			} catch (SQLException e) { 
				e.printStackTrace();
			}			
		} // finally 

	} //

} // 
