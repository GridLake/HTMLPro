package days04;

import java.io.IOException;
import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		Scanner  scanner = new Scanner(System.in);
		System.out.print("> 글번호 입력 ? ");  
		int seq = scanner.nextInt(); 
		System.out.print("> 글쓴이 입력 ? ");  
		String name = scanner.nextLine();  
		System.out.print("> 비밀번호 입력 ? ");
		String password = scanner.nextLine();   
		System.out.print("> 제목 입력 ? ");
		String subject = scanner.nextLine();  
		 
		System.out.println(name +"/"+ password +"/" + subject);
		
		
		

	}

	private static void skip() {
		try {
			System.in.skip(System.in.available());
		} catch (IOException e) { 
			e.printStackTrace();
		}
	}

}










